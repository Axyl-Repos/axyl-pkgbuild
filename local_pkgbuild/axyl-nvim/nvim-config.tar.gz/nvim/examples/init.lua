-- example file i.e lua/custom/init.lua

-- load your globals, autocmds here or anything .__.
